package abdn;

import static org.junit.Assert.*;

import org.junit.Test;

// Class for testing the package
public class AppTest 
{
    // Here we have only one example test, please try to do more
    @Test
    public void testAddition()
    {
        Calculator calc = new Calculator();
        assertEquals( 10, calc.add(2,8));
    }
}
