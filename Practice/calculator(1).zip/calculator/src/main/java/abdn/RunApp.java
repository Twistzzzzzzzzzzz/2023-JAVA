package abdn; // Remember to include the class in the package!

import java.util.Scanner; // For user input

class RunApp {
    static public void main(String[] args) {
        char ch = ' ';
        Calculator calc = new Calculator();
        Scanner in = new Scanner(System.in);
        do {
            System.out.printf("Enter the first value: ");
            int a = in.nextInt();
            System.out.printf("Enter operator '+','-','*', or 'q' to quit: ");
            ch = in.next().charAt(0);
            if(ch != 'Q' && ch != 'q') {
                System.out.printf("Enter the second value: ");
                int b = in.nextInt();
                int res = 0;
                if(ch == '+') {
                    System.out.printf("Result: %d%n", calc.add(a,b));
                } 
                else if(ch == '-') {
                    System.out.printf("Result: %d%n", calc.subtract(a,b));
                }
                else if(ch == '*') {
                    System.out.printf("Result: %d%n", calc.multiply(a,b));
                }
                else {
                    System.out.println("Illegal operation!");
                }
            }
        } while(ch != 'Q' && ch != 'q');
    }
}