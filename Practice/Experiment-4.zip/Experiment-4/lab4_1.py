#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""to build a binary tree with binary linked list"""

class BTNode():
    def __init__(self, data = None, lchild = None, rchild = None):
        self.data = data
        self.lchild = lchild  # left child
        self.rchild = rchild  # right child

def creatBinTree():
    # finally return root node
    ch = input('Please input an alphabet, to note that \"*\" stands for None: ')
    pass


def preorder(T): #per-order traversal
    pass


def postorder(T): #post-order traversal
    pass


def inorder(T): #in-order traversal
    pass

def levelorder(T): #level-order traversal by queue
    pass

def countleaf(T): #count the number of leaf nodes
    pass



def inorder2(T): # in-order traversal by stack (non-recursive)
    pass


if __name__ == '__main__':
    #with the pre-order traversed sequence as input：AB*D**C**. "*" stands for NONE.
    bt = creatBinTree()
    print('pre-order traversal: ')
    preorder(bt)
    print('\n')
    
    print('post-order traversal： ')
    postorder(bt)
    print('\n')
    
    print('in-order traversal： ')
    inorder(bt)
    print('\n')
    
    print('level-order traversal： ')
    levelorder(bt)
    print('\n')

    n = 0 #global variant to save the number of leaf nodes
    countleaf(bt)
    print('The number of leaf nodes is: ', n)
    print('\n')



    print('in-order traversal by non-recursive way： ')
    inorder2(bt)



