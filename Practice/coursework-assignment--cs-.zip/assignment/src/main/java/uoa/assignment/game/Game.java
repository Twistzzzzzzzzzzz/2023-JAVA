package uoa.assignment.game;

import uoa.assignment.character.Monster;

public class Game {
    

    
    Game (int height, int width) {
    }
    			
    public Map getMap() {
        return null;
    }
    
    public boolean nextRound (String input) {
        return true;
    }
   
}