package uoa.assignment.game;

import uoa.assignment.character.GameCharacter;
import uoa.assignment.character.Monster;
import uoa.assignment.character.Player;

public class Map {

public String [][] layout;
public GameCharacter characters [] ;
 
  Map (int height, int width) {
	 
  }
 
  public void printLayout() {
	
   }
}
