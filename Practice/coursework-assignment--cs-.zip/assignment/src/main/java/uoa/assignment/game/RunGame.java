package uoa.assignment.game;

public class RunGame {

	private static boolean gameOver = false;

	public static void main(String[] args) {
		
        while (!gameOver) {
			//complete the code
		}
	}

}
