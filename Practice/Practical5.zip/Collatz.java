import java.util.Scanner;

public class Collatz {

    // The first parameter n represents the Collatz sequence (Task 5.1),
    // the second parameter i represents the number of steps (Task 5.3)
    public static int collatz(int n, int i) throws IllegalArgumentException {
        
        // Add this for Task 5.2
        if(n <= 0) {
            throw(new IllegalArgumentException());
        }
        System.out.println("Next: " + n);
        if(n == 1)
            return i;
        if(n % 2 == 0) 
            i = collatz(n/2, i+1);
        else
            i = collatz(3*n+1, i+1);
        return i;
    }

    public static void main(String[] args) {
        System.out.print("Give the initial value n: ");
        int n = (new Scanner(System.in)).nextInt();

        // Add try...catch structure for Task 5.2
        try {
            System.out.println("Steps: " + collatz(n,0));
        } catch(IllegalArgumentException e){
            System.out.println("n must be a positive integer!");
        }
    }
}