// RunApp.java for Tasks 5.4-5.6

import java.util.*; 
import java.lang.*; 

public class RunApp {
    static public void main(String[] args) {
        char ch = ' ';
        Calculator calc = new Calculator();
        Scanner in = new Scanner(System.in);
        do {
            try {
            System.out.printf("Enter the first value: ");
            int a = in.nextInt();
            System.out.printf("Enter operator '+','-','*','/', or 'q' to quit: ");
            ch = in.next().charAt(0);
            if(ch != 'Q' && ch != 'q') {
                System.out.printf("Enter the second value: ");
                int b = in.nextInt();
                int res = 0;
                if(ch == '+') {
                    System.out.printf("Result: %d%n", calc.add(a,b));
                } 
                else if(ch == '-') {
                    System.out.printf("Result: %d%n", calc.subtract(a,b));
                }
                else if(ch == '*') {
                    System.out.printf("Result: %d%n", calc.multiply(a,b));
                }
                else if(ch == '/') {
                    System.out.printf("Result: %d%n", calc.divide(a,b));
                }
                else {
                    System.out.println("Illegal operation!");
                }
            }
            } catch(InputMismatchException e) {
                System.out.println("Invalid input!");
                in.nextLine();
            } catch(ArithmeticException e) {
                System.out.println("Division by zero!");
            } catch(NotDivisibleException e) {
                System.out.println("Not divisible!");
            }
        } while(ch != 'Q' && ch != 'q');
    }
}